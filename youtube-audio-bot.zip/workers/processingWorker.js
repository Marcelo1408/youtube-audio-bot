const DownloadService = require('../services/downloadService');
const Processing = require('../models/Processing');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const db = require('../config/database');
const path = require('path');

class ProcessingWorker {
    constructor(bot) {
        this.bot = bot;
        this.queue = [];
        this.isProcessing = false;
    }

    async addJob(processingId, chatId) {
        this.queue.push({ processingId, chatId });
        
        if (!this.isProcessing) {
            this.processQueue();
        }
        
        return this.queue.length;
    }

    async processQueue() {
        if (this.queue.length === 0 || this.isProcessing) {
            return;
        }

        this.isProcessing = true;
        
        while (this.queue.length > 0) {
            const job = this.queue.shift();
            await this.processJob(job.processingId, job.chatId);
        }
        
        this.isProcessing = false;
    }

    async processJob(processingId, chatId) {
        let processing = null;
        
        try {
            // Atualizar status para processando
            processing = await Processing.findById(processingId);
            if (!processing) {
                throw new Error('Processamento não encontrado');
            }
            
            await Processing.updateStatus(processingId, 'processing');
            
            // Notificar usuário
            await this.bot.sendMessage(chatId, 
                '⚙️ *Processando vídeo...*\n\n' +
                `🔗 ${processing.video_url.substring(0, 50)}...\n` +
                `🎚️ Qualidade: ${processing.quality}\n` +
                `📁 Formato: ${processing.format}\n\n` +
                '_Isso pode levar alguns minutos..._',
                { parse_mode: 'Markdown' }
            );
            
            // Obter informações do vídeo
            const videoInfo = await DownloadService.getVideoInfo(processing.video_url);
            
            // Baixar vídeo
            await this.bot.sendMessage(chatId, '📥 Baixando vídeo do YouTube...');
            
            const downloadResult = await DownloadService.downloadVideo(
                videoInfo.id,
                {
                    quality: processing.quality,
                    format: processing.format
                }
            );
            
            // Extrair áudio
            await this.bot.sendMessage(chatId, '🎵 Extraindo áudio...');
            
            // Dividir por silêncio
            await this.bot.sendMessage(chatId, '🔊 Detectando músicas...');
            const tracks = await DownloadService.splitAudioBySilence(
                downloadResult.audioPath,
                processing.format
            );
            
            // Criar ZIP
            await this.bot.sendMessage(chatId, '📦 Criando arquivo ZIP...');
            const zipPath = await DownloadService.createZipFromTracks(
                tracks,
                `audio_${videoInfo.id}`
            );
            
            // Atualizar processamento
            await Processing.complete(
                processingId,
                {
                    videoTitle: videoInfo.title,
                    tracksCount: tracks.length,
                    zipFilePath: zipPath,
                    fileSize: await DownloadService.getFileSize(zipPath)
                }
            );
            
            // Enviar para usuário
            await this.bot.sendMessage(chatId, 
                '✅ *Processamento completo!*\n\n' +
                `🎵 ${tracks.length} música(s) extraída(s)\n` +
                `📁 Formato: ${processing.format.toUpperCase()}\n` +
                `💾 Tamanho: ${(await DownloadService.getFileSize(zipPath) / 1024 / 1024).toFixed(2)}MB\n\n` +
                '_Enviando arquivo..._',
                { parse_mode: 'Markdown' }
            );
            
            // Enviar arquivo
            const sendResult = await DownloadService.uploadToTelegram(
                this.bot,
                chatId,
                zipPath,
                `🎵 ${videoInfo.title}\n` +
                `🎚️ Qualidade: ${processing.quality}\n` +
                `📁 Formato: ${processing.format}\n` +
                `🎶 Faixas: ${tracks.length}`
            );
            
            if (sendResult.success) {
                if (sendResult.method === 'link') {
                    await this.bot.sendMessage(chatId, 
                        '📤 *Arquivo disponível para download*\n\n' +
                        'O arquivo foi enviado via link devido ao tamanho.\n' +
                        'Use o link abaixo para baixar:',
                        { parse_mode: 'Markdown' }
                    );
                }
                
                // Limpar arquivos temporários após sucesso
                setTimeout(() => {
                    DownloadService.cleanupJob(downloadResult.jobDir);
                }, 5000);
                
            } else {
                throw new Error('Erro ao enviar arquivo: ' + sendResult.error);
            }
            
        } catch (error) {
            console.error('Erro no processamento:', error);
            
            if (processing) {
                await Processing.fail(processingId, error.message);
            }
            
            await this.bot.sendMessage(chatId,
                '❌ *Erro no processamento*\n\n' +
                `_${error.message}_\n\n` +
                'Tente novamente ou entre em contato com o suporte.',
                { parse_mode: 'Markdown' }
            );
        }
    }

    async getQueueStatus() {
        return {
            queueLength: this.queue.length,
            isProcessing: this.isProcessing,
            currentJob: this.queue[0]
        };
    }
}

module.exports = ProcessingWorker;