const ytdl = require('ytdl-core');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

class YouTubeService {
    constructor() {
        this.downloadsDir = path.join(__dirname, '../downloads');
        this.ensureDirectoryExists(this.downloadsDir);
    }

    ensureDirectoryExists(dir) {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    }

    isValidUrl(url) {
        return ytdl.validateURL(url);
    }

    async getVideoInfo(url) {
        try {
            const info = await ytdl.getInfo(url);
            return {
                title: info.videoDetails.title,
                duration: info.videoDetails.lengthSeconds,
                thumbnail: info.videoDetails.thumbnails[0].url
            };
        } catch (error) {
            throw new Error('Erro ao obter informações do vídeo');
        }
    }

    async downloadAudio(url, options = {}) {
        const { quality = 'medium', format = 'mp3' } = options;
        const timestamp = Date.now();
        const outputDir = path.join(this.downloadsDir, timestamp.toString());
        
        this.ensureDirectoryExists(outputDir);

        const bitrates = {
            'low': '128k',
            'medium': '192k',
            'high': '256k',
            'veryhigh': '320k'
        };

        const outputFile = path.join(outputDir, `audio.${format}`);
        
        return new Promise((resolve, reject) => {
            const audioStream = ytdl(url, {
                filter: 'audioonly',
                quality: 'highestaudio'
            });

            const command = ffmpeg(audioStream)
                .audioBitrate(bitrates[quality])
                .format(format)
                .on('error', (err) => {
                    console.error('Erro FFmpeg:', err);
                    reject(err);
                })
                .on('end', () => {
                    resolve({
                        filePath: outputFile,
                        format,
                        quality
                    });
                });

            command.save(outputFile);
        });
    }

    async splitAudioBySilence(audioPath, format) {
        // Implementar detecção de silêncio e divisão de áudio
        // Usando ffmpeg para detectar silêncio
        // Esta é uma implementação simplificada
        
        const tracks = [];
        const outputDir = path.dirname(audioPath);
        
        // Exemplo de detecção de silêncio (implementação básica)
        // Em produção, use uma biblioteca como pydub ou implemente a lógica de detecção
        
        // Para exemplo, vamos criar um arquivo único
        tracks.push({
            title: 'Track 1',
            startTime: 0,
            endTime: 300, // 5 minutos
            filePath: audioPath
        });

        return tracks;
    }

    async createZipFromTracks(tracks, videoTitle) {
        const zip = new AdmZip();
        const outputDir = path.dirname(tracks[0].filePath);
        const zipPath = path.join(outputDir, `${videoTitle}.zip`);

        tracks.forEach((track, index) => {
            if (fs.existsSync(track.filePath)) {
                const trackName = `Track_${index + 1}.${path.extname(track.filePath)}`;
                zip.addLocalFile(track.filePath, '', trackName);
            }
        });

        zip.writeZip(zipPath);
        return zipPath;
    }

    async cleanupFiles(dir) {
        if (fs.existsSync(dir)) {
            fs.rmSync(dir, { recursive: true, force: true });
        }
    }
}

module.exports = new YouTubeService();