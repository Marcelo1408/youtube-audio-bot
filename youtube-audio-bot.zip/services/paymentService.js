const mercadopago = require('mercadopago');

class PaymentService {
    constructor() {
        mercadopago.configure({
            access_token: process.env.MP_ACCESS_TOKEN
        });
    }

    async createPayment(paymentData) {
        const { userId, telegramId, amount, description } = paymentData;

        const payment_data = {
            transaction_amount: amount,
            description: description,
            payment_method_id: 'pix',
            payer: {
                email: `user_${telegramId}@telegram.com`,
                first_name: 'Telegram',
                identification: {
                    type: 'CPF',
                    number: '00000000000' // Em produção, colete esses dados
                }
            },
            notification_url: 'https://seusite.com/webhook/mercadopago',
            metadata: {
                userId: userId.toString(),
                telegramId: telegramId,
                type: 'coin_purchase'
            }
        };

        try {
            const payment = await mercadopago.payment.create(payment_data);
            return payment.body;
        } catch (error) {
            console.error('Erro Mercado Pago:', error);
            throw error;
        }
    }

    async checkPaymentStatus(paymentId) {
        try {
            const payment = await mercadopago.payment.get(paymentId);
            return payment.body.status;
        } catch (error) {
            console.error('Erro ao verificar pagamento:', error);
            return 'error';
        }
    }
}

module.exports = new PaymentService();