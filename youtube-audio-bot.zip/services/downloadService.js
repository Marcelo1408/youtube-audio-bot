const ytdl = require('ytdl-core');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const { promisify } = require('util');
const stream = require('stream');
const pipeline = promisify(stream.pipeline);
const AdmZip = require('adm-zip');
const axios = require('axios');

ffmpeg.setFfmpegPath(ffmpegPath);

class DownloadService {
    constructor() {
        this.baseDir = process.env.DOWNLOAD_DIR || '/opt/youtube-audio-bot/downloads';
        this.maxFileSize = parseInt(process.env.MAX_FILE_SIZE_MB || '50') * 1024 * 1024;
        this.ensureDirectoryExists(this.baseDir);
    }

    ensureDirectoryExists(dir) {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    }

    async getVideoInfo(url) {
        try {
            const info = await ytdl.getInfo(url);
            return {
                id: info.videoDetails.videoId,
                title: info.videoDetails.title,
                duration: parseInt(info.videoDetails.lengthSeconds),
                thumbnail: info.videoDetails.thumbnails[0].url,
                author: info.videoDetails.author.name,
                size: this.estimateSize(parseInt(info.videoDetails.lengthSeconds)),
                formats: info.formats
            };
        } catch (error) {
            throw new Error(`Erro ao obter informações do vídeo: ${error.message}`);
        }
    }

    estimateSize(durationSeconds) {
        // Estimativa: 1 minuto ≈ 1MB para áudio de qualidade média
        return Math.ceil(durationSeconds / 60) * 1024 * 1024;
    }

    async downloadVideo(videoId, options = {}) {
        const { quality = 'highestaudio', format = 'mp3' } = options;
        const timestamp = Date.now();
        const jobDir = path.join(this.baseDir, `${videoId}_${timestamp}`);
        
        this.ensureDirectoryExists(jobDir);
        
        const tempVideoPath = path.join(jobDir, 'video_temp.mp4');
        const outputAudioPath = path.join(jobDir, `audio.${format}`);
        
        return new Promise((resolve, reject) => {
            try {
                const videoStream = ytdl(videoId, {
                    quality: quality,
                    filter: 'audioonly'
                });

                const writeStream = fs.createWriteStream(tempVideoPath);
                
                videoStream.on('error', (error) => {
                    reject(new Error(`Erro no download: ${error.message}`));
                });

                videoStream.on('progress', (chunkLength, downloaded, total) => {
                    // Monitorar progresso do download
                    const percent = (downloaded / total) * 100;
                    console.log(`Download: ${percent.toFixed(2)}%`);
                });

                videoStream.pipe(writeStream);

                writeStream.on('finish', () => {
                    console.log('Download completo, convertendo áudio...');
                    this.convertToAudio(tempVideoPath, outputAudioPath, format)
                        .then(() => {
                            // Remover vídeo temporário
                            fs.unlinkSync(tempVideoPath);
                            
                            resolve({
                                audioPath: outputAudioPath,
                                jobDir: jobDir,
                                format: format,
                                size: fs.statSync(outputAudioPath).size
                            });
                        })
                        .catch(reject);
                });

                writeStream.on('error', reject);

            } catch (error) {
                reject(new Error(`Erro ao iniciar download: ${error.message}`));
            }
        });
    }

    async convertToAudio(inputPath, outputPath, format) {
        return new Promise((resolve, reject) => {
            ffmpeg(inputPath)
                .audioCodec(format === 'mp3' ? 'libmp3lame' : 
                          format === 'wav' ? 'pcm_s16le' : 
                          format === 'flac' ? 'flac' : 'aac')
                .audioBitrate('192k')
                .format(format)
                .on('start', (commandLine) => {
                    console.log('FFmpeg iniciado:', commandLine);
                })
                .on('progress', (progress) => {
                    if (progress.percent) {
                        console.log(`Conversão: ${progress.percent.toFixed(2)}%`);
                    }
                })
                .on('end', () => {
                    console.log('Conversão completa');
                    resolve();
                })
                .on('error', (error) => {
                    reject(new Error(`Erro na conversão: ${error.message}`));
                })
                .save(outputPath);
        });
    }

    async splitAudioBySilence(audioPath, format = 'mp3') {
        const jobDir = path.dirname(audioPath);
        const tracksDir = path.join(jobDir, 'tracks');
        
        this.ensureDirectoryExists(tracksDir);
        
        // Detectar silêncios usando FFmpeg
        const silenceData = await this.detectSilence(audioPath);
        
        if (silenceData.length === 0) {
            // Se não encontrar silêncios, retorna o áudio completo como uma faixa
            return [{
                title: 'Full Audio',
                startTime: 0,
                endTime: await this.getAudioDuration(audioPath),
                filePath: audioPath
            }];
        }
        
        const tracks = [];
        
        // Criar faixas baseadas nos silêncios detectados
        for (let i = 0; i < silenceData.length; i++) {
            const startTime = i === 0 ? 0 : silenceData[i-1].end;
            const endTime = silenceData[i].start;
            
            if (endTime - startTime < 2) {
                continue; // Ignorar segmentos muito curtos
            }
            
            const trackNumber = i + 1;
            const trackFileName = `track_${trackNumber}.${format}`;
            const trackPath = path.join(tracksDir, trackFileName);
            
            await this.extractAudioSegment(audioPath, trackPath, startTime, endTime);
            
            tracks.push({
                title: `Track ${trackNumber}`,
                trackNumber: trackNumber,
                startTime: startTime,
                endTime: endTime,
                duration: endTime - startTime,
                filePath: trackPath,
                size: fs.statSync(trackPath).size
            });
        }
        
        return tracks;
    }

    async detectSilence(audioPath) {
        return new Promise((resolve, reject) => {
            const silenceDetections = [];
            
            ffmpeg(audioPath)
                .audioFilters('silencedetect=noise=-30dB:d=2')
                .format('null')
                .output('/dev/null')
                .on('stderr', (stderrLine) => {
                    // Parse FFmpeg output for silence detection
                    const silenceStartMatch = stderrLine.match(/silence_start: (\d+(\.\d+)?)/);
                    const silenceEndMatch = stderrLine.match(/silence_end: (\d+(\.\d+)?)/);
                    
                    if (silenceStartMatch) {
                        silenceDetections.push({
                            start: parseFloat(silenceStartMatch[1])
                        });
                    }
                    
                    if (silenceEndMatch && silenceDetections.length > 0) {
                        const lastDetection = silenceDetections[silenceDetections.length - 1];
                        if (!lastDetection.end) {
                            lastDetection.end = parseFloat(silenceEndMatch[1]);
                        }
                    }
                })
                .on('end', () => {
                    resolve(silenceDetections.filter(d => d.start && d.end));
                })
                .on('error', reject)
                .run();
        });
    }

    async getAudioDuration(audioPath) {
        return new Promise((resolve, reject) => {
            ffmpeg.ffprobe(audioPath, (err, metadata) => {
                if (err) reject(err);
                resolve(metadata.format.duration);
            });
        });
    }

    async extractAudioSegment(inputPath, outputPath, startTime, endTime) {
        return new Promise((resolve, reject) => {
            const duration = endTime - startTime;
            
            ffmpeg(inputPath)
                .setStartTime(startTime)
                .setDuration(duration)
                .on('end', resolve)
                .on('error', reject)
                .save(outputPath);
        });
    }

    async createZipFromTracks(tracks, zipName) {
        const jobDir = path.dirname(tracks[0].filePath);
        const zipPath = path.join(jobDir, `${zipName}.zip`);
        const zip = new AdmZip();
        
        tracks.forEach(track => {
            const trackFileName = `${track.trackNumber}_${track.title.replace(/[^a-z0-9]/gi, '_')}.${path.extname(track.filePath).substring(1)}`;
            zip.addLocalFile(track.filePath, '', trackFileName);
        });
        
        zip.writeZip(zipPath);
        return zipPath;
    }

    async cleanupJob(jobDir) {
        try {
            // Manter apenas por 24 horas para debug
            const files = fs.readdirSync(jobDir);
            const now = Date.now();
            
            for (const file of files) {
                const filePath = path.join(jobDir, file);
                const stat = fs.statSync(filePath);
                
                // Se o arquivo tem mais de 24 horas, deletar
                if (now - stat.mtime.getTime() > 24 * 60 * 60 * 1000) {
                    fs.unlinkSync(filePath);
                }
            }
        } catch (error) {
            console.error('Erro na limpeza:', error.message);
        }
    }

    async getFileSize(filePath) {
        try {
            const stats = fs.statSync(filePath);
            return stats.size;
        } catch (error) {
            return 0;
        }
    }

    async compressAudio(inputPath, outputPath, quality = 'medium') {
        const bitrates = {
            'low': '128k',
            'medium': '192k',
            'high': '256k',
            'veryhigh': '320k'
        };

        return new Promise((resolve, reject) => {
            ffmpeg(inputPath)
                .audioBitrate(bitrates[quality])
                .on('end', resolve)
                .on('error', reject)
                .save(outputPath);
        });
    }

    async uploadToTelegram(bot, chatId, filePath, caption = '') {
        const maxSize = 20 * 1024 * 1024; // 20MB
        
        try {
            const fileSize = await this.getFileSize(filePath);
            
            if (fileSize <= maxSize) {
                // Enviar diretamente se menor que 20MB
                await bot.sendDocument(chatId, filePath, {
                    caption: caption
                });
                return { success: true, method: 'direct' };
            } else {
                // Se maior que 20MB, criar link de download
                const fileName = path.basename(filePath);
                const downloadUrl = await this.createDownloadLink(filePath, fileName);
                
                await bot.sendMessage(chatId, 
                    `📁 *Arquivo Grande*\n\n` +
                    `O arquivo *${fileName}* é muito grande para enviar pelo Telegram (${(fileSize / 1024 / 1024).toFixed(2)}MB).\n\n` +
                    `📥 *Baixe aqui:*\n` +
                    `🔗 ${downloadUrl}\n\n` +
                    `⚠️ O link expira em 24 horas.`,
                    { parse_mode: 'Markdown' }
                );
                
                return { success: true, method: 'link', url: downloadUrl };
            }
        } catch (error) {
            console.error('Erro ao enviar para Telegram:', error);
            return { success: false, error: error.message };
        }
    }

    async createDownloadLink(filePath, fileName) {
        // Implementação simplificada
        // Em produção, use um serviço de hospedagem ou servidor web
        
        const baseUrl = process.env.BASE_URL || 'http://localhost:3000';
        const token = Math.random().toString(36).substring(7);
        
        // Em produção, salve o token no banco de dados com expiração
        // e configure um endpoint para servir o arquivo
        
        return `${baseUrl}/download/${token}/${fileName}`;
    }

    async createDirectDownloadEndpoint(app, bot) {
        // Criar endpoint para download direto
        app.get('/download/:token/:filename', async (req, res) => {
            try {
                const { token, filename } = req.params;
                
                // Verificar token (implementar validação adequada)
                const filePath = path.join(this.baseDir, '...', filename);
                
                if (!fs.existsSync(filePath)) {
                    return res.status(404).send('Arquivo não encontrado');
                }
                
                res.download(filePath, filename, (err) => {
                    if (err) {
                        console.error('Erro no download:', err);
                    }
                    
                    // Opcional: deletar após download
                    // fs.unlinkSync(filePath);
                });
            } catch (error) {
                res.status(500).send('Erro no servidor');
            }
        });
    }
}

module.exports = new DownloadService();