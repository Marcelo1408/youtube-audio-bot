const userKeyboard = {
    keyboard: [
        ['🎵 Extrair Áudio', '💰 Recarregar via PIX'],
        ['📜 Histórico', '👤 Meus Dados'],
        ['💳 Planos & Pagamentos']
    ],
    resize_keyboard: true
};

// Teclado específico para pagamentos
const paymentKeyboard = {
    keyboard: [
        ['💵 Recarga Rápida', '📋 Ver Planos'],
        ['❓ Como Pagar', '🔙 Voltar ao Menu']
    ],
    resize_keyboard: true
};

// Teclado para recarga rápida
const quickPaymentKeyboard = {
    keyboard: [
        ['🎫 50 moedas - R$ 9,90', '🎫 100 moedas - R$ 15,90'],
        ['🎫 200 moedas - R$ 25,90', '📋 Todos os Planos'],
        ['🔙 Voltar']
    ],
    resize_keyboard: true
};

module.exports = {
    adminKeyboard,
    userKeyboard,
    paymentKeyboard,
    quickPaymentKeyboard
};