const db = require('../config/database');

class User {
    // Criar usuário
    static async create(telegramId, username, firstName, lastName = '') {
        const [result] = await db.execute(
            `INSERT INTO users (telegram_id, username, first_name, last_name, coins, plan, is_active, is_admin, created_at, updated_at)
             VALUES (?, ?, ?, ?, 0, 'free', TRUE, FALSE, NOW(), NOW())`,
            [telegramId, username, firstName, lastName]
        );
        return result.insertId;
    }

    // Buscar por Telegram ID
    static async findByTelegramId(telegramId) {
        const [rows] = await db.execute(
            `SELECT * FROM users WHERE telegram_id = ?`,
            [telegramId]
        );
        return rows[0] || null;
    }

    // Buscar por ID
    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT * FROM users WHERE id = ?`,
            [id]
        );
        return rows[0] || null;
    }

    // Buscar por username
    static async findByUsername(username) {
        const [rows] = await db.execute(
            `SELECT * FROM users WHERE username = ?`,
            [username]
        );
        return rows[0] || null;
    }

    // Atualizar moedas
    static async updateCoins(userId, coins) {
        const [result] = await db.execute(
            `UPDATE users SET coins = ?, updated_at = NOW() WHERE id = ?`,
            [coins, userId]
        );
        return result.affectedRows > 0;
    }

    // Adicionar moedas
    static async addCoins(userId, amount) {
        const [result] = await db.execute(
            `UPDATE users SET coins = coins + ?, updated_at = NOW() WHERE id = ?`,
            [amount, userId]
        );
        return result.affectedRows > 0;
    }

    // Remover moedas
    static async removeCoins(userId, amount) {
        const [result] = await db.execute(
            `UPDATE users SET coins = coins - ?, updated_at = NOW() WHERE id = ? AND coins >= ?`,
            [amount, userId, amount]
        );
        return result.affectedRows > 0;
    }

    // Atualizar plano
    static async updatePlan(userId, plan) {
        const [result] = await db.execute(
            `UPDATE users SET plan = ?, updated_at = NOW() WHERE id = ?`,
            [plan, userId]
        );
        return result.affectedRows > 0;
    }

    // Listar todos os usuários (admin)
    static async findAll(limit = 100, offset = 0) {
        const [rows] = await db.execute(
            `SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [limit, offset]
        );
        return rows;
    }

    // Buscar usuários ativos
    static async findActiveUsers() {
        const [rows] = await db.execute(
            `SELECT * FROM users WHERE is_active = TRUE ORDER BY created_at DESC`
        );
        return rows;
    }

    // Estatísticas do usuário
    static async getUserStats(userId) {
        const [rows] = await db.execute(
            `SELECT * FROM user_statistics WHERE id = ?`,
            [userId]
        );
        return rows[0] || null;
    }

    // Deletar usuário
    static async delete(userId) {
        const [result] = await db.execute(
            `DELETE FROM users WHERE id = ?`,
            [userId]
        );
        return result.affectedRows > 0;
    }

    // Verificar se é admin
    static async isAdmin(userId) {
        const [rows] = await db.execute(
            `SELECT is_admin FROM users WHERE id = ?`,
            [userId]
        );
        return rows[0] ? rows[0].is_admin : false;
    }

    // Verificar se tem moedas suficientes
    static async hasEnoughCoins(userId, amount) {
        const [rows] = await db.execute(
            `SELECT coins, plan FROM users WHERE id = ?`,
            [userId]
        );
        
        if (!rows[0]) return false;
        
        // Plano infinito não precisa de moedas
        if (rows[0].plan === 'infinite') return true;
        
        return rows[0].coins >= amount;
    }

    // Buscar usuário com bloqueio (para transações)
    static async findByIdForUpdate(id) {
        const [rows] = await db.execute(
            `SELECT * FROM users WHERE id = ? FOR UPDATE`,
            [id]
        );
        return rows[0] || null;
    }

    // Contar total de usuários
    static async count() {
        const [rows] = await db.execute(`SELECT COUNT(*) as total FROM users`);
        return rows[0].total;
    }

    // Buscar usuários por plano
    static async findByPlan(plan, limit = 100) {
        const [rows] = await db.execute(
            `SELECT * FROM users WHERE plan = ? ORDER BY created_at DESC LIMIT ?`,
            [plan, limit]
        );
        return rows;
    }

    // Atualizar informações do usuário
    static async update(userId, data) {
        const fields = [];
        const values = [];
        
        for (const [key, value] of Object.entries(data)) {
            fields.push(`${key} = ?`);
            values.push(value);
        }
        
        fields.push('updated_at = NOW()');
        
        const query = `UPDATE users SET ${fields.join(', ')} WHERE id = ?`;
        values.push(userId);
        
        const [result] = await db.execute(query, values);
        return result.affectedRows > 0;
    }

    // Buscar usuário e criar se não existir
    static async findOrCreate(telegramId, username, firstName, lastName = '') {
        let user = await this.findByTelegramId(telegramId);
        
        if (!user) {
            const userId = await this.create(telegramId, username, firstName, lastName);
            user = await this.findById(userId);
        }
        
        return user;
    }
}

module.exports = User;