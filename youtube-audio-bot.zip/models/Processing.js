const mongoose = require('mongoose');

const processingSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    videoUrl: {
        type: String,
        required: true
    },
    videoTitle: String,
    quality: {
        type: String,
        enum: ['low', 'medium', 'high', 'veryhigh'],
        default: 'medium'
    },
    format: {
        type: String,
        enum: ['mp3', 'wav', 'flac', 'm4a'],
        default: 'mp3'
    },
    status: {
        type: String,
        enum: ['pending', 'processing', 'completed', 'failed'],
        default: 'pending'
    },
    tracks: [{
        title: String,
        startTime: Number,
        endTime: Number,
        filePath: String
    }],
    zipFilePath: String,
    coinsUsed: {
        type: Number,
        default: 10
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    completedAt: Date
});

module.exports = mongoose.model('Processing', processingSchema);