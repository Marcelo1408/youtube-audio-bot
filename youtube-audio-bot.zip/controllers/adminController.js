const User = require('../models/User');

const adminController = {
    async handleAdminCommand(bot, msg, adminUser) {
        const chatId = msg.chat.id;
        const text = msg.text;

        switch(text) {
            case '👥 Criar Usuário':
                this.showCreateUserMenu(bot, chatId);
                break;
            case '📊 Estatísticas':
                this.showStatistics(bot, chatId);
                break;
            case '💰 Gerenciar Moedas':
                this.showCoinManagement(bot, chatId);
                break;
            case '🔙 Voltar':
                bot.sendMessage(chatId, 'Menu principal:', {
                    reply_markup: adminKeyboard
                });
                break;
            default:
                if (text.startsWith('@')) {
                    await this.createUserByUsername(bot, chatId, text.substring(1));
                }
        }
    },

    showCreateUserMenu(bot, chatId) {
        const options = {
            reply_markup: {
                keyboard: [
                    ['👤 Essencial (150 moedas - R$19,90)', '⭐ Premium (250 moedas - R$35,99)'],
                    ['👑 Deluxe (450 moedas - R$45,99)', '∞ Infinito (moedas ilimitadas)'],
                    ['🔙 Voltar']
                ],
                resize_keyboard: true
            }
        };

        bot.sendMessage(chatId, 'Selecione o tipo de usuário para criar:', options);
    },

    async createUserByUsername(bot, chatId, username) {
        try {
            // Implementar criação de usuário pelo username
            // Aqui você precisaria de uma forma de obter o telegramId pelo username
            // Isso pode requerer que o usuário tenha interagido com o bot antes
            
            bot.sendMessage(chatId, '⚠️ Para criar usuário, peça para ele usar /start no bot primeiro, então use o ID.');
        } catch (error) {
            bot.sendMessage(chatId, '❌ Erro ao criar usuário: ' + error.message);
        }
    },

    async showStatistics(bot, chatId) {
        try {
            const totalUsers = await User.countDocuments();
            const activeUsers = await User.countDocuments({ isActive: true });
            const premiumUsers = await User.countDocuments({ plan: { $ne: 'free' } });
            
            const stats = `📊 *Estatísticas do Sistema*\n\n` +
                         `👥 Total de Usuários: *${totalUsers}*\n` +
                         `✅ Usuários Ativos: *${activeUsers}*\n` +
                         `⭐ Usuários Premium: *${premiumUsers}*\n` +
                         `💰 Receita Total: *A implementar*`;
            
            bot.sendMessage(chatId, stats, { parse_mode: 'Markdown' });
        } catch (error) {
            bot.sendMessage(chatId, '❌ Erro ao obter estatísticas');
        }
    },

    async showCoinManagement(bot, chatId) {
        bot.sendMessage(chatId, 'Digite o @username do usuário e a quantidade de moedas:\n\nExemplo: @usuario 100');
    }
};

module.exports = adminController;