const User = require('../models/User');
const Processing = require('../models/Processing');
const Transaction = require('../models/Transaction');
const youtubeService = require('../services/youtubeService');
const audioProcessingService = require('../services/audioProcessingService');
const moment = require('moment');
const ProcessingWorker = require('../workers/processingWorker');
const DownloadService = require('../services/downloadService');

const userController = {
    async handleUserCommand(bot, msg, user, userStates) {
        const chatId = msg.chat.id;
        const text = msg.text;
        const state = userStates.get(chatId) || {};

        switch(text) {
            case '🎵 Extrair Áudio':
                userStates.set(chatId, { ...state, action: 'awaiting_url' });
                this.showHeader(bot, chatId, user);
                bot.sendMessage(chatId, '📥 *Envie o link do vídeo do YouTube:*', {
                    parse_mode: 'Markdown'
                });
                break;

            case '💰 Recarregar Moedas':
            case '💰 Recarregar via PIX':
            case '💳 Planos & Pagamentos':
                this.showPaymentMenu(bot, chatId, user);
                break;

            case '💵 Recarga Rápida':
                this.showQuickPaymentOptions(bot, chatId, user);
                break;

            case '📋 Ver Planos':
                this.showAllPlans(bot, chatId, user);
                break;

            case '📜 Histórico':
                this.showHistory(bot, chatId, user);
                break;

            case '👤 Meus Dados':
                this.showUserInfo(bot, chatId, user);
                break;

            case '❓ Como Pagar':
                this.showPaymentInstructions(bot, chatId);
                break;

            case '🔙 Voltar ao Menu':
                this.showMainMenu(bot, chatId, user);
                break;

            default:
                if (text.startsWith('🎫 ')) {
                    await this.processQuickPayment(bot, chatId, user, text);
                } else if (state.action === 'awaiting_url') {
                    await this.processVideoUrl(bot, chatId, user, text, userStates);
                }
        }
    },

    showHeader(bot, chatId, user) {
        const now = moment();
        const dateStr = now.format('DD/MM/YYYY');
        const timeStr = now.format('HH:mm:ss');
        
        bot.sendMessage(chatId, 
            `👤 *${user.firstName}* | ${dateStr} ${timeStr}\n💰 Moedas: *${user.coins}*`, {
            parse_mode: 'Markdown'
        });
    },

    async processVideoUrl(bot, chatId, user, url, userStates) {
        try {
            // Verificar se tem moedas suficientes
            if (user.plan !== 'infinite' && user.coins < 10) {
                bot.sendMessage(chatId, '❌ Moedas insuficientes! Recarregue suas moedas.');
                return;
            }

            // Validar URL do YouTube
            if (!DownloadService.isValidUrl(url)) {
                bot.sendMessage(chatId, '❌ Link inválido! Envie um link válido do YouTube.');
                return;
            }

            // Obter informações do vídeo para validação
            await bot.sendMessage(chatId, '🔍 Obtendo informações do vídeo...');
            const videoInfo = await DownloadService.getVideoInfo(url);
            
            // Verificar se o vídeo é muito longo (opcional)
            const maxDuration = 2 * 60 * 60; // 2 horas máximo
            if (videoInfo.duration > maxDuration) {
                bot.sendMessage(chatId, 
                    '❌ *Vídeo muito longo*\n\n' +
                    `Duração: ${Math.floor(videoInfo.duration / 60)} minutos\n` +
                    'O vídeo excede o limite máximo de 2 horas.\n' +
                    'Por favor, selecione um vídeo mais curto.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }

            // Estimar tamanho
            const estimatedSize = DownloadService.estimateSize(videoInfo.duration);
            const maxSize = DownloadService.maxFileSize;
            
            if (estimatedSize > maxSize) {
                bot.sendMessage(chatId,
                    '⚠️ *Vídeo muito grande*\n\n' +
                    `Tamanho estimado: ${(estimatedSize / 1024 / 1024).toFixed(2)}MB\n` +
                    `Limite: ${(maxSize / 1024 / 1024).toFixed(2)}MB\n\n` +
                    'O processamento pode falhar devido ao tamanho.',
                    { parse_mode: 'Markdown' }
                );
            }

            // Salvar URL no estado
            const state = userStates.get(chatId) || {};
            state.videoUrl = url;
            state.videoInfo = videoInfo;
            userStates.set(chatId, state);

            // Mostrar informações do vídeo
            bot.sendMessage(chatId,
                `📹 *Informações do Vídeo*\n\n` +
                `🎬 **${videoInfo.title}**\n` +
                `👤 ${videoInfo.author}\n` +
                `⏱️ ${Math.floor(videoInfo.duration / 60)}:${(videoInfo.duration % 60).toString().padStart(2, '0')}\n` +
                `📊 Tamanho estimado: ${(estimatedSize / 1024 / 1024).toFixed(2)}MB\n\n` +
                `_Selecione a qualidade do áudio:_`,
                { parse_mode: 'Markdown' }
            );

            // Mostrar opções de qualidade
            this.showQualityOptions(bot, chatId);

        } catch (error) {
            bot.sendMessage(chatId, '❌ Erro ao processar o link: ' + error.message);
        }
    },

    showQualityOptions(bot, chatId) {
        const keyboard = {
            inline_keyboard: [
                [
                    { text: '🔈 Baixa (128kbps)', callback_data: 'quality_low' },
                    { text: '🔉 Média (192kbps)', callback_data: 'quality_medium' }
                ],
                [
                    { text: '🔊 Alta (256kbps)', callback_data: 'quality_high' },
                    { text: '🎵 Muito Alta (320kbps)', callback_data: 'quality_veryhigh' }
                ]
            ]
        };

        bot.sendMessage(chatId, '🎚️ *Selecione a qualidade do áudio:*', {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    async handleQualitySelection(bot, callbackQuery, user, userStates) {
        const chatId = callbackQuery.message.chat.id;
        const quality = callbackQuery.data.split('_')[1];
        
        // Atualizar estado
        const state = userStates.get(chatId) || {};
        state.quality = quality;
        userStates.set(chatId, state);

        // Mostrar opções de formato
        this.showFormatOptions(bot, chatId);
    },

    showFormatOptions(bot, chatId) {
        const keyboard = {
            inline_keyboard: [
                [
                    { text: 'MP3 (Recomendado)', callback_data: 'format_mp3' },
                    { text: 'WAV', callback_data: 'format_wav' }
                ],
                [
                    { text: 'FLAC', callback_data: 'format_flac' },
                    { text: 'M4A', callback_data: 'format_m4a' }
                ]
            ]
        };

        bot.sendMessage(chatId, '📁 *Selecione o formato do áudio:*', {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    async handleFormatSelection(bot, callbackQuery, user, userStates) {
        const chatId = callbackQuery.message.chat.id;
        const format = callbackQuery.data.split('_')[1];
        
        const state = userStates.get(chatId) || {};
        state.format = format;
        userStates.set(chatId, state);

        // Confirmar processamento
        this.confirmProcessing(bot, chatId, user, state);
    },

    async confirmProcessing(bot, chatId, user, state) {
        const confirmKeyboard = {
            inline_keyboard: [
                [
                    { text: '✅ Confirmar (10 moedas)', callback_data: 'confirm_process' },
                    { text: '❌ Cancelar', callback_data: 'cancel_process' }
                ]
            ]
        };

        bot.sendMessage(chatId, 
            `📋 *Confirmação de Processamento*\n\n` +
            `🎬 **${state.videoInfo.title}**\n` +
            `⏱️ ${Math.floor(state.videoInfo.duration / 60)} minutos\n` +
            `🎚️ Qualidade: ${state.quality}\n` +
            `📁 Formato: ${state.format}\n` +
            `💰 Custo: 10 moedas\n\n` +
            `Seu saldo atual: ${user.coins} moedas\n\n` +
            `⚠️ *Atenção:*\n` +
            `• O processamento é feito na VPS\n` +
            `• Arquivos grandes serão enviados via link\n` +
            `• Pode levar alguns minutos`,
            {
                parse_mode: 'Markdown',
                reply_markup: confirmKeyboard
            }
        );
    },

    async handleProcessConfirmation(bot, callbackQuery, user, userStates, processingWorker) {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;
        
        if (data === 'confirm_process') {
            const state = userStates.get(chatId) || {};
            
            try {
                // Criar registro de processamento no banco
                const processingId = await Processing.create({
                    userId: user.id,
                    videoUrl: state.videoUrl,
                    quality: state.quality,
                    format: state.format,
                    status: 'pending'
                });
                
                // Debitar moedas (exceto plano infinito)
                if (user.plan !== 'infinite') {
                    await User.removeCoins(user.id, 10);
                    
                    // Registrar transação
                    await Transaction.create({
                        userId: user.id,
                        type: 'video_processing',
                        amount: 0,
                        coinsAmount: -10,
                        description: `Processamento: ${state.videoInfo.title.substring(0, 100)}`,
                        status: 'completed'
                    });
                }
                
                // Adicionar à fila de processamento
                const queuePosition = await processingWorker.addJob(processingId, chatId);
                
                await bot.sendMessage(chatId,
                    `✅ *Processamento iniciado!*\n\n` +
                    `🎬 **${state.videoInfo.title}**\n` +
                    `📊 Posição na fila: #${queuePosition}\n` +
                    `⏱️ Tempo estimado: ${queuePosition * 5} minutos\n\n` +
                    `_Você será notificado quando estiver pronto._`,
                    { parse_mode: 'Markdown' }
                );
                
                // Limpar estado
                userStates.delete(chatId);
                
            } catch (error) {
                await bot.sendMessage(chatId,
                    '❌ *Erro ao iniciar processamento*\n\n' +
                    `_${error.message}_`,
                    { parse_mode: 'Markdown' }
                );
            }
        } else if (data === 'cancel_process') {
            userStates.delete(chatId);
            await bot.sendMessage(chatId, '❌ Processamento cancelado.');
        }
    },

    showPaymentMenu(bot, chatId, user) {
        this.showHeader(bot, chatId, user);
        
        const message = `💳 *MENU DE PAGAMENTOS*\n\n` +
                       `Selecione uma opção abaixo:`;

        const keyboard = {
            reply_markup: {
                keyboard: [
                    ['💵 Recarga Rápida', '📋 Ver Planos'],
                    ['❓ Como Pagar', '🔙 Voltar ao Menu']
                ],
                resize_keyboard: true
            }
        };

        bot.sendMessage(chatId, message, { 
            parse_mode: 'Markdown',
            ...keyboard
        });
    },

    showQuickPaymentOptions(bot, chatId, user) {
        const quickPlans = [
            { name: 'Mini', coins: 50, price: 9.90 },
            { name: 'Básico', coins: 100, price: 15.90 },
            { name: 'Plus', coins: 200, price: 25.90 }
        ];

        let message = '💵 *RECARGA RÁPIDA*\n\n';
        const keyboard = { inline_keyboard: [] };

        quickPlans.forEach(plan => {
            message += `*${plan.name}*\n` +
                      `🎫 ${plan.coins} moedas\n` +
                      `💵 R$ ${plan.price.toFixed(2)}\n\n`;

            keyboard.inline_keyboard.push([
                { 
                    text: `${plan.coins} moedas - R$ ${plan.price.toFixed(2)}`, 
                    callback_data: `quick_${plan.coins}`
                }
            ]);
        });

        keyboard.inline_keyboard.push([
            { text: '📋 Ver Todos os Planos', callback_data: 'show_all_plans' }
        ]);

        message += 'Selecione uma opção para gerar o PIX:';

        bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    showAllPlans(bot, chatId, user) {
        const plans = [
            { name: 'Essencial', coins: 150, price: 19.90, callback: 'pay_essential' },
            { name: 'Premium', coins: 250, price: 35.99, callback: 'pay_premium' },
            { name: 'Deluxe', coins: 450, price: 45.99, callback: 'pay_deluxe' }
        ];

        let message = '📋 *TODOS OS PLANOS*\n\n';
        const keyboard = { inline_keyboard: [] };

        plans.forEach(plan => {
            message += `*${plan.name}*\n` +
                      `🎫 ${plan.coins} moedas\n` +
                      `💵 R$ ${plan.price.toFixed(2)}\n` +
                      `📱 PIX\n\n`;

            keyboard.inline_keyboard.push([
                { 
                    text: `${plan.name} - R$ ${plan.price.toFixed(2)}`, 
                    callback_data: plan.callback 
                }
            ]);
        });

        keyboard.inline_keyboard.push([
            { text: '💵 Recarga Rápida', callback_data: 'quick_recharge' },
            { text: '🔙 Voltar', callback_data: 'back_to_menu' }
        ]);

        message += 'Selecione um plano para gerar o PIX:';

        bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    async processQuickPayment(bot, chatId, user, text) {
        try {
            // Extrair informações do texto (ex: "🎫 50 moedas - R$ 9,90")
            const match = text.match(/🎫 (\d+) moedas - R\$ (\d+,\d+)/);
            if (!match) {
                bot.sendMessage(chatId, '❌ Formato inválido. Use os botões do menu.');
                return;
            }

            const coins = parseInt(match[1]);
            const price = parseFloat(match[2].replace(',', '.'));

            // Aqui você implementaria a geração do PIX
            bot.sendMessage(chatId, 
                `💰 *GERANDO PIX*\n\n` +
                `🎫 ${coins} moedas\n` +
                `💵 R$ ${price.toFixed(2)}\n\n` +
                `_Implemente a geração do PIX aqui..._`, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            bot.sendMessage(chatId, '❌ Erro ao processar pagamento: ' + error.message);
        }
    },

    showPaymentInstructions(bot, chatId) {
        const message = `❓ *COMO PAGAR VIA PIX*\n\n` +
                       `1️⃣ *Selecione um plano* no menu de pagamentos\n` +
                       `2️⃣ *Escaneie o QR Code* que será gerado\n` +
                       `3️⃣ *Confirme o pagamento* no seu app bancário\n` +
                       `4️⃣ *Aguarde a confirmação* (automática em até 2 minutos)\n\n` +
                       `⚠️ *IMPORTANTE:*\n` +
                       `• O QR Code é válido por 30 minutos\n` +
                       `• Após o pagamento, suas moedas serão creditadas automaticamente\n` +
                       `• Em caso de problemas, contate o suporte\n\n` +
                       `💰 *MÉTODOS DE PAGAMENTO:*\n` +
                       `• PIX (QR Code ou chave)\n` +
                       `• Cartão de crédito (em breve)\n` +
                       `• Boleto bancário (em breve)`;

        bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    showMainMenu(bot, chatId, user) {
        this.showHeader(bot, chatId, user);
        
        const keyboard = {
            reply_markup: {
                keyboard: [
                    ['🎵 Extrair Áudio', '💰 Recarregar Moedas'],
                    ['📜 Histórico', '👤 Meus Dados']
                ],
                resize_keyboard: true
            }
        };

        bot.sendMessage(chatId, '📱 *MENU PRINCIPAL*\n\nSelecione uma opção:', {
            parse_mode: 'Markdown',
            ...keyboard
        });
    },

    async showPaymentOptions(bot, chatId, user) {
        const plans = [
            { name: 'Essencial', coins: 150, price: 19.90, callback: 'pay_essential' },
            { name: 'Premium', coins: 250, price: 35.99, callback: 'pay_premium' },
            { name: 'Deluxe', coins: 450, price: 45.99, callback: 'pay_deluxe' }
        ];

        let message = '💰 *PLANOS DE RECARGA*\n\n';
        const keyboard = { inline_keyboard: [] };

        plans.forEach(plan => {
            message += `*${plan.name}*\n` +
                      `🎫 ${plan.coins} moedas\n` +
                      `💵 R$ ${plan.price.toFixed(2)}\n` +
                      `📱 PIX\n\n`;

            keyboard.inline_keyboard.push([
                { 
                    text: `${plan.name} - R$ ${plan.price.toFixed(2)}`, 
                    callback_data: plan.callback 
                }
            ]);
        });

        message += 'Selecione um plano para gerar o PIX:';

        bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    },

    async showHistory(bot, chatId, user) {
        try {
            const processes = await Processing.find({ userId: user._id })
                .sort({ createdAt: -1 })
                .limit(10);

            if (processes.length === 0) {
                bot.sendMessage(chatId, '📭 Nenhum processamento encontrado no histórico.');
                return;
            }

            let message = '📜 *HISTÓRICO DE PROCESSAMENTOS*\n\n';
            
            processes.forEach((proc, index) => {
                const date = moment(proc.createdAt).format('DD/MM/YYYY HH:mm');
                const statusIcons = {
                    'pending': '⏳',
                    'processing': '⚙️',
                    'completed': '✅',
                    'failed': '❌'
                };

                message += `*${index + 1}. ${proc.videoTitle || 'Sem título'}*\n` +
                          `${statusIcons[proc.status]} Status: ${proc.status}\n` +
                          `📅 Data: ${date}\n` +
                          `💰 Moedas: ${proc.coinsUsed}\n` +
                          `🔗 ${proc.videoUrl.substring(0, 30)}...\n\n`;
            });

            bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } catch (error) {
            console.error('Erro ao carregar histórico:', error);
            bot.sendMessage(chatId, '❌ Erro ao carregar histórico.');
        }
    },

    async showUserInfo(bot, chatId, user) {
        const planNames = {
            'free': '🆓 Gratuito',
            'essential': '👤 Essencial',
            'premium': '⭐ Premium',
            'deluxe': '👑 Deluxe',
            'infinite': '∞ Infinito'
        };

        const message = `👤 *SEUS DADOS*\n\n` +
                       `Nome: ${user.firstName} ${user.lastName || ''}\n` +
                       `Username: @${user.username}\n` +
                       `ID: ${user.telegramId}\n` +
                       `Plano: ${planNames[user.plan]}\n` +
                       `💰 Moedas: ${user.coins}\n` +
                       `📅 Cadastrado em: ${moment(user.createdAt).format('DD/MM/YYYY')}\n` +
                       `✅ Status: ${user.isActive ? 'Ativo' : 'Inativo'}`;

        bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    },

    async handleCallbackQuery(bot, callbackQuery, user, userStates) {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;

        if (data.startsWith('quality_')) {
            await this.handleQualitySelection(bot, callbackQuery, user, userStates);
        } else if (data.startsWith('format_')) {
            await this.handleFormatSelection(bot, callbackQuery, user, userStates);
        } else if (data === 'quick_recharge') {
            this.showQuickPaymentOptions(bot, chatId, user);
        } else if (data === 'show_all_plans') {
            this.showAllPlans(bot, chatId, user);
        } else if (data === 'back_to_menu') {
            this.showMainMenu(bot, chatId, user);
        } else if (data.startsWith('quick_')) {
            const coins = data.split('_')[1];
            // Implementar geração de PIX para recarga rápida
            bot.sendMessage(chatId, `Gerando PIX para ${coins} moedas...`);
        } else if (data === 'confirm_process' || data === 'cancel_process') {
            // Precisamos passar o processingWorker também
            // Isso será tratado em outro lugar ou podemos modificar a assinatura
            // Por enquanto, vamos apenas enviar uma mensagem
            if (data === 'confirm_process') {
                bot.sendMessage(chatId, '⚠️ Confirmação de processamento. Implemente handleProcessConfirmation.');
            } else {
                bot.sendMessage(chatId, '❌ Processamento cancelado.');
                // Limpar estado
                const state = userStates.get(chatId);
                if (state) {
                    userStates.delete(chatId);
                }
            }
        }
    }
};

module.exports = userController;