const User = require('../models/User');
const Transaction = require('../models/Transaction');
const paymentService = require('../services/paymentService');
const qrcode = require('qrcode');

const paymentController = {
    async handlePayment(bot, callbackQuery, user) {
        const chatId = callbackQuery.message.chat.id;
        const planType = callbackQuery.data.split('_')[1];

        const plans = {
            'essential': { coins: 150, price: 19.90 },
            'premium': { coins: 250, price: 35.99 },
            'deluxe': { coins: 450, price: 45.99 }
        };

        const plan = plans[planType];
        
        if (!plan) {
            bot.sendMessage(chatId, '❌ Plano inválido.');
            return;
        }

        try {
            // Criar pagamento no Mercado Pago
            const payment = await paymentService.createPayment({
                userId: user._id,
                telegramId: user.telegramId,
                amount: plan.price,
                description: `Recarga de ${plan.coins} moedas - Plano ${planType}`
            });

            // Gerar QR Code PIX
            const qrCodeData = payment.point_of_interaction.transaction_data.qr_code;
            const qrCodeImage = await qrcode.toDataURL(qrCodeData);

            // Enviar instruções de pagamento
            const message = `💰 *PAGAMENTO VIA PIX*\n\n` +
                           `Plano: *${planType.toUpperCase()}*\n` +
                           `Valor: *R$ ${plan.price.toFixed(2)}*\n` +
                           `Moedas: *${plan.coins}*\n\n` +
                           `1. Abra seu app de pagamentos\n` +
                           `2. Escaneie o QR Code abaixo\n` +
                           `3. Confira os dados e pague\n` +
                           `4. As moedas serão creditadas automaticamente\n\n` +
                           `⏱️ *Válido por 30 minutos*`;

            // Enviar QR Code (em produção, você precisaria enviar a imagem)
            bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            
            // Em produção, enviar a imagem do QR Code
            // bot.sendPhoto(chatId, qrCodeImage, { caption: 'QR Code PIX' });

        } catch (error) {
            console.error('Erro no pagamento:', error);
            bot.sendMessage(chatId, '❌ Erro ao processar pagamento.');
        }
    },

    async verifyPayment(paymentId) {
        // Verificar status do pagamento no Mercado Pago
        const status = await paymentService.checkPaymentStatus(paymentId);
        
        if (status === 'approved') {
            // Atualizar moedas do usuário
            const transaction = await Transaction.findOne({ paymentId });
            if (transaction) {
                const user = await User.findById(transaction.userId);
                const plan = this.getPlanByAmount(transaction.amount);
                
                user.coins += plan.coins;
                await user.save();
                
                transaction.status = 'completed';
                await transaction.save();
                
                // Notificar usuário
                bot.sendMessage(user.telegramId, 
                    `✅ *Pagamento confirmado!*\n\n` +
                    `💰 ${plan.coins} moedas adicionadas à sua conta.\n` +
                    `🎉 Total atual: ${user.coins} moedas`, {
                    parse_mode: 'Markdown'
                });
            }
        }
    },

    getPlanByAmount(amount) {
        const plans = [
            { amount: 19.90, coins: 150 },
            { amount: 35.99, coins: 250 },
            { amount: 45.99, coins: 450 }
        ];
        
        return plans.find(p => p.amount === amount) || { coins: 0 };
    }
};

module.exports = paymentController;