const mysql = require('mysql2/promise');
require('dotenv').config();

class Database {
    constructor() {
        this.pool = null;
        this.initialize();
    }

    async initialize() {
        try {
            this.pool = mysql.createPool({
                host: process.env.MYSQL_HOST || 'localhost',
                user: process.env.MYSQL_USER || 'youtube_bot_user',
                password: process.env.MYSQL_PASSWORD || 'BotSecurePass123!',
                database: process.env.MYSQL_DATABASE || 'youtube_audio_bot',
                port: process.env.MYSQL_PORT || 3306,
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0,
                enableKeepAlive: true,
                keepAliveInitialDelay: 0,
                timezone: 'Z',
                charset: 'utf8mb4',
                supportBigNumbers: true,
                bigNumberStrings: true,
                dateStrings: true,
                multipleStatements: false,
                typeCast: function(field, next) {
                    if (field.type === 'TINY' && field.length === 1) {
                        return field.string() === '1';
                    }
                    if (field.type === 'JSON') {
                        try {
                            return JSON.parse(field.string());
                        } catch (e) {
                            return field.string();
                        }
                    }
                    return next();
                }
            });

            // Testar conexão
            const connection = await this.pool.getConnection();
            console.log('✅ Conectado ao MySQL');
            
            // Verificar se as tabelas existem
            await this.checkTables();
            
            connection.release();
        } catch (error) {
            console.error('❌ Erro ao conectar ao MySQL:', error.message);
            process.exit(1);
        }
    }

    async checkTables() {
        const requiredTables = ['users', 'transactions', 'processings', 'system_settings'];
        
        for (const table of requiredTables) {
            try {
                const [rows] = await this.pool.execute(`SHOW TABLES LIKE '${table}'`);
                if (rows.length === 0) {
                    console.warn(`⚠️  Tabela '${table}' não encontrada. Execute o schema.sql`);
                }
            } catch (error) {
                console.error(`❌ Erro ao verificar tabela '${table}':`, error.message);
            }
        }
    }

    async execute(query, params = []) {
        try {
            const [rows] = await this.pool.execute(query, params);
            return rows;
        } catch (error) {
            console.error('❌ Erro na query:', error.message);
            console.error('Query:', query);
            console.error('Params:', params);
            throw error;
        }
    }

    async transaction(callback) {
        const connection = await this.pool.getConnection();
        
        try {
            await connection.beginTransaction();
            const result = await callback(connection);
            await connection.commit();
            return result;
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    async ping() {
        try {
            await this.pool.execute('SELECT 1');
            return true;
        } catch (error) {
            return false;
        }
    }

    async close() {
        if (this.pool) {
            await this.pool.end();
            console.log('✅ Conexão com MySQL fechada');
        }
    }
}

// Singleton
const database = new Database();

// Exportar métodos úteis
module.exports = {
    pool: database.pool,
    execute: database.execute.bind(database),
    transaction: database.transaction.bind(database),
    ping: database.ping.bind(database),
    close: database.close.bind(database)
};